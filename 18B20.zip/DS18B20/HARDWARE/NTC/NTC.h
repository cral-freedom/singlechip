#include "sys.h"
u8 look_up_table(const unsigned int *a,u8 ArrayLong,u16 data);
int16_t read_NTC1(u16 Val_NTC);
